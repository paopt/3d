# 在线课程地址：
https://ke.qq.com/course/393957

## 项目结构

```bash
dist/ # 项目打包目录
src/ # 源代码目录
  assets # 资源目录
  index.js # 入口
```

## 开始开发

> npm install # 安装依赖
> npm start # 启动项目
> http://localhost:9000 # 访问


